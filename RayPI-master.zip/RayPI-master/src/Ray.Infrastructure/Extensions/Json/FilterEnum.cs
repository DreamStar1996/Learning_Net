﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ray.Infrastructure.Extensions.Json
{
    public enum FilterEnum
    {
        Ignore,
        Retain
    }
}
