﻿namespace Ray.Infrastructure.Test
{
    public interface ITest
    {
        void Run();
    }
}
