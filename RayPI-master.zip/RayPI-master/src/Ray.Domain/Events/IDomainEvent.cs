﻿namespace Ray.Domain.Events
{
    public interface IDomainEvent
    {
    }
}
