﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ray.Domain.Entities.Attributes
{
    public class DisableIdGenerationAttribute : Attribute
    {
    }
}
