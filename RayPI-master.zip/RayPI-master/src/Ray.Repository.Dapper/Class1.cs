﻿using System;

namespace Ray.Infrastructure.Repository.Dapper
{
    public class Class1
    {
        //todo:待实现
    }
}
