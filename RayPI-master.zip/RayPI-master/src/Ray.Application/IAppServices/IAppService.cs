﻿namespace Ray.Application.IAppServices
{
    /// <summary>
    /// 定义一个AppService
    /// </summary>
    public interface IAppService
    {
    }
}
