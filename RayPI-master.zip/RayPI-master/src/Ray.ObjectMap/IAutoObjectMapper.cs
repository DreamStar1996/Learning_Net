﻿namespace Ray.ObjectMap
{
    /// <summary>
    /// 自动化Mapper映射器
    /// </summary>
    public interface IAutoObjectMapper : IObjectMapper
    {

    }
}
