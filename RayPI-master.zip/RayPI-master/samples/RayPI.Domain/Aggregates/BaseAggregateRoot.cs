﻿namespace RayPI.Domain.Aggregates
{
    public abstract class BaseAggregateRoot : BaseEntity
    {
    }
}
