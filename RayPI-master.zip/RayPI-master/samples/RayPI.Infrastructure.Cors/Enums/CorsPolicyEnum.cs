﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RayPI.Infrastructure.Cors.Enums
{
    public enum CorsPolicyEnum
    {
        Free,
        Limit
    }
}
