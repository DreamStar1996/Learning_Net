﻿namespace RayPI.Infrastructure.Security.Models
{
    /// <summary>
    /// 一个 API
    /// </summary>
    public  class ApiInfoModel
    {
        public string ApiName { get; set; }
        public string ApiUrl { get; set; }
    }
}
