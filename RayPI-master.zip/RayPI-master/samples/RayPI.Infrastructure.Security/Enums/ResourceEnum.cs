﻿namespace RayPI.Infrastructure.Security.Enums
{
    public enum ResourceEnum
    {
        Student
    }
}
