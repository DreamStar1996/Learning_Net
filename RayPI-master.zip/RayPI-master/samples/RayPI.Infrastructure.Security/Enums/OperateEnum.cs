﻿namespace RayPI.Infrastructure.Security.Enums
{
    public enum OperateEnum
    {
        Create,
        Retrieve,
        Update,
        Delete,
    }
}
