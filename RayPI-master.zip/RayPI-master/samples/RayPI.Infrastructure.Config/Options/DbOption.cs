﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RayPI.Infrastructure.Config.Options
{
    public class DbOption
    {
        public string ConnStr { get; set; }
    }
}
