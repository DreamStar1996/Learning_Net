﻿namespace RayPI.Infrastructure.Auth.Enums
{
    public enum OperateEnum
    {
        All,
        Create,
        Retrieve,
        Update,
        Delete,
    }
}
