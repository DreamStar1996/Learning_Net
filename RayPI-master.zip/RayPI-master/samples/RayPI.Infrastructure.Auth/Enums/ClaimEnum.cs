﻿
namespace RayPI.Infrastructure.Auth.Enums
{
    /// <summary>
    /// Claim声明类型名称枚举
    /// </summary>
    public enum ClaimTypeEnum
    {
        TokenModel
    }
}
