﻿namespace RayPI.Infrastructure.Auth.Enums
{
    public enum ResourceEnum
    {
        All,
        Student,
        Teacher
    }
}
