﻿using Microsoft.AspNetCore.Authorization;

namespace RayPI.Infrastructure.Auth.Attributes
{
    public class RayAuthorizeFreeAttribute : AllowAnonymousAttribute
    {
    }
}
